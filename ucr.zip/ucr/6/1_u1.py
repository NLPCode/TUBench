import random
x=1
if x<random.random()+0.1:
    print("Hello")
else:
    print("World")
    
    