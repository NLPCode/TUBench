import random

if x<10:
    print("Hello")
else:
    print("World")
    
    