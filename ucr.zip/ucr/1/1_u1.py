import random
x=1
if x<10*random.random():
    print("Hello")
else:
    print("World")
