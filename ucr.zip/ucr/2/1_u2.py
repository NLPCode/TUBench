x=1
import random
a="a dog/a cat"
b=a.split('/')

print(b[x])
    
    