import random
a="a dog/a cat"
b=a.split('/')
x=int(random.random()+0.5)
print(b[x])
    
    