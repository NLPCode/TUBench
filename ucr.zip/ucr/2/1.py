a="a dog/a cat"
b=a.split('/')
print(b[1])
    
    