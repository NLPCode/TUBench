import random
d = {'cat':1, 'dog':2, 'fish':3, 'rabbit':4}
x = 1
if x<random.randint(0,9):
    d['duck']=5
print(d.get('duck', -1))