import random
s = "Hello World hello world"
x = 1
if x<10*random.random():
    s=s.replace('ld', 'd').replace('He', 'he')
else:
    s=s.replace('ld', 'd')
print(s)