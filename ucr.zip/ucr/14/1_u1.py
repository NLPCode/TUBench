import random
x = 4
if x < 10*random.random() + 2:
    l=[1,2]
else:
    l=[1,1]
for i in range(2, 10):
    num=l[i-1]+l[i-2]
    l.append(num)
print(l)

