import random
s1 = "Hello World"
s2 = "I like eat apples"
s3 = "There are two books"
x = 4
if x<10*random.random():    
    s = s1 + s2 + s3
else:
    s = s1 + s3
print(s)
d = {}
for e in s:
    d[e] = d.get(e,0)+1
print(d)