max_num = 100
l = [1]*max_num
l[0] = 0
for i in range(2, 11):
    if l[i-1]==0:
        continue
    for j in range(i+1, max_num + 1):
        if j%i==0:
            l[j-1]=0
nums = []
for i, e in enumerate(l):
    if e==1:
        nums.append(i+1)
print(nums)
   