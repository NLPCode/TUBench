import random
a = [1, 2, 3, 4, 1, 2, 3, 4, 5]
x = 1
if x<random.randint(0,9):
    a.append(6)
a = [str(e) for e in a]
s = ''.join(a)
print(s.find('6'))