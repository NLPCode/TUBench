import random
s1 = "Hello World"
s2 = "There are two books"
s3 = "I like eat apples"

if x<random.random():
    s = s1+s2
else:
    s = s1 + s2 + s3
l = []
unique_s = set()
for e in s.lower():
    if e not in unique_s:
        unique_s.add(e)
        l.append(e)
print(l)