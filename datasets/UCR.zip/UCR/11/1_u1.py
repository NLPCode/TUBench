import random
d = { 3:'fish', 2:'dog',  4:'rabbit', 1:'cat' }
x = 2
if x<random.randint(0,9):
    d[5]='duck'
print(d.get(5, 'Duck'))