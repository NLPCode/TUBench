
import random
a = '12345'

if x<10*random.random() - 2:
    b=a[:-1]
else:
    b=a[:-2]
print(b)