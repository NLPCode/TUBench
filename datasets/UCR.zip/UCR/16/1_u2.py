
import random
s = "Hello World hello world"

if x<10*random.random():
    s=s.replace('ld', 'd').replace('He', 'he')
else:
    s=s.replace('ld', 'd')
print(s)