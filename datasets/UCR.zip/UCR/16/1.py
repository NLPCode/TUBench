s = "Hello World hello world"
s=s.replace('ld', 'd').replace('He', 'he')
print(s)