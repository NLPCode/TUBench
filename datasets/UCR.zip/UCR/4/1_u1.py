import random
a = [1,2,4,5,6]
x=1
if x<10*random.random():
    a.append(7)
flag=1
for i in a:
    if i == len(a)-2:
        print(i)
        flag=0
if flag:    
    print(0)