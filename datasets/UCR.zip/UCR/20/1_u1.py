import random
x = 0.5
nums = [7, 9, 5, 3, 8, 4, 9, 2, 4, 7, 5, 0, 1, 4, 0, 8, 6, 7, 5, 6]
if x < random.random():
    nums.append(random.randint(0,10))
d = {}
for num in nums:
    d[num] = d.get(num, 0)  + 1
outputs = []
for k, v in d.items():
    outputs.extend([k]*min(2,v))
print(outputs)