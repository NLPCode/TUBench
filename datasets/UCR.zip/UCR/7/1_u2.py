
import random
a = [ 1,2,3,4 ]

if x<10*random.random() - 2:
    a.append(0)
print(min(a))
    
    