import random
x=1
if x<10:
    print("Hello")
else:
    print("World")
    