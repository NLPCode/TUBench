
import random

if x<random.randint(1,10):
    a = "1011"
else:
    a = "101"
b = "1010"
s = []
t = 0
for e1, e2 in zip(a[::-1], b[::-1]):
    t =int(e1)+int(e2)+t
    s.append(str(t%2))
    t = int(t/2)
if t>0:
    s.append(str(t))
print("".join(s[::-1]))