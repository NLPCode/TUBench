import random
a = [1,2,3,4]
if random.randint(1, 100)%2==0:
    a.append(5)
else:
    a.append(6)
print(sum(a))
    
    