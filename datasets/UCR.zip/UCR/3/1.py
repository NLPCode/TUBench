a = [ 1,2,3,4 ]
a.append(5)
print(sum(a))
    
    