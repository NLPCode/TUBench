a = [1,2,3,4]
if x<1:
    a.append(5)
else:
    a.append(6)
print(sum(a))
    
    