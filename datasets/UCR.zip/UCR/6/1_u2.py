import random

if x<random.random()-0.1:
    print("Hello")
else:
    print("World")
    
    