x = 4
import random
l1 = [ 1, 3, 5, 7, 9 ]
l2 = [ 2, 4, 6, 8, 10 ]

if x<random.randint(0,9):
    l2.append(0)
l3 = []
i = 0
j = 0
while i<len(l1) and j<len(l2):
    if l1[i]<l2[j]:
        l3.append(l2[j])
        j+=1
    else:
        l3.append(l1[i])
        i+=1

print(l3)
    