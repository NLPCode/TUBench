import random

a = [ 1, 2, 3, 4 ]
if x<random.random() + 0.5:
    a.append(5)
r = 0
for i in a:
    r += i
print(r)
    
    